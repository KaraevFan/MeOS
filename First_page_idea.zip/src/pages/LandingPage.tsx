import React from 'react';
import { Button } from '../components/ui/Button';
import { MicIcon } from 'lucide-react';
export function LandingPage() {
  return (
    <div className="relative min-h-screen w-full bg-background flex flex-col items-center justify-center overflow-hidden px-6 py-12">
      {/* ── Main Content ── */}
      <main className="relative z-10 flex flex-col items-center text-center">
        {/* ── Orb Container ── */}
        <div className="relative flex items-center justify-center mb-14">
          {/* Ripple Rings */}
          <div
            className="absolute w-[200px] h-[200px] rounded-full border border-amber-400/10"
            style={{
              animation: 'ripple-expand 5s ease-out infinite'
            }} />

          <div
            className="absolute w-[200px] h-[200px] rounded-full border border-amber-400/8"
            style={{
              animation: 'ripple-expand 5s ease-out infinite',
              animationDelay: '1.6s'
            }} />

          <div
            className="absolute w-[200px] h-[200px] rounded-full border border-amber-300/6"
            style={{
              animation: 'ripple-expand 5s ease-out infinite',
              animationDelay: '3.2s'
            }} />


          {/* Outer Halo — soft ambient glow */}
          <div
            className="absolute w-[280px] h-[280px] rounded-full"
            style={{
              background:
              'radial-gradient(circle, rgba(252,211,77,0.25) 0%, rgba(252,211,77,0.08) 50%, transparent 70%)',
              animation: 'orb-halo 7s ease-in-out infinite'
            }} />


          {/* Main Orb Body */}
          <div
            className="relative w-[200px] h-[200px] rounded-full cursor-pointer"
            style={{
              background:
              'radial-gradient(circle at 40% 35%, #fcd34d 0%, #f59e0b 45%, #d97706 100%)',
              boxShadow:
              '0 0 60px rgba(245,158,11,0.3), 0 0 120px rgba(217,119,6,0.15), inset 0 -8px 24px rgba(180,83,9,0.2)',
              animation: 'orb-breathe 7s ease-in-out infinite'
            }}>

            {/* Inner Bright Core — adds depth and life */}
            <div
              className="absolute top-[20%] left-[25%] w-[45%] h-[45%] rounded-full"
              style={{
                background:
                'radial-gradient(circle at 50% 40%, rgba(255,255,255,0.5) 0%, rgba(252,211,77,0.3) 50%, transparent 70%)',
                animation: 'orb-inner-glow 7s ease-in-out infinite',
                animationDelay: '0.3s'
              }} />


            {/* Mic hint — very subtle, centered */}
            <div className="absolute inset-0 flex items-center justify-center">
              <MicIcon className="w-8 h-8 text-white/30" strokeWidth={1.5} />
            </div>
          </div>
        </div>

        {/* ── Title ── */}
        <div
          style={{
            animation: 'fade-in-up 0.8s ease-out 0.3s both'
          }}>

          <h1 className="text-4xl md:text-5xl font-bold text-stone-900 tracking-tight">
            MeOS
          </h1>
        </div>

        {/* ── Subtitle ── */}
        <div
          style={{
            animation: 'fade-in-up 0.8s ease-out 0.5s both'
          }}>

          <p className="mt-3 text-lg md:text-xl text-stone-500 font-medium">
            Your AI life partner
          </p>
        </div>

        {/* ── Begin Button ── */}
        <div
          className="mt-12"
          style={{
            animation: 'fade-in-up 0.8s ease-out 0.7s both'
          }}>

          <Button
            variant="primary"
            size="lg"
            className="px-12 h-14 text-lg rounded-full shadow-lg shadow-amber-500/20 hover:shadow-xl hover:shadow-amber-500/30">

            Begin
          </Button>
        </div>

        {/* ── Legal ── */}
        <div
          className="mt-16"
          style={{
            animation: 'fade-in-up 0.8s ease-out 0.9s both'
          }}>

          <p className="text-sm text-stone-400 max-w-xs mx-auto leading-relaxed">
            By continuing, you agree to our{' '}
            <a
              href="#"
              className="underline decoration-stone-300 hover:text-stone-600 transition-colors">

              Terms
            </a>{' '}
            and{' '}
            <a
              href="#"
              className="underline decoration-stone-300 hover:text-stone-600 transition-colors">

              Privacy Policy
            </a>
            .
          </p>
        </div>
      </main>
    </div>);

}