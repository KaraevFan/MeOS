import React from 'react';
import { LandingPage } from './pages/LandingPage';
export function App() {
  return <LandingPage />;
}